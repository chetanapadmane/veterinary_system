<?php

header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

$postdata = file_get_contents("php://input");
$request = json_decode($postdata);

function myfunction(){
    echo 'myfun';
}

function createConnection(){
    $hostname = "localhost";
    $username = "root";
    $password = "";
    $database = "veterinary_system";

    $conn = new mysqli($hostname, $username, $password, $database);
    return $conn;
}

// if ($_SERVER['REQUEST_METHOD'] === 'POST') {
//     // echo 'post request';
//     //create connection or open connection
    
//     if ($conn->connect_error) {
//         echo "Connection failed: " . $conn->connect_error;
//     } else {
//         echo "Connected successfully";
//     }

//     $sqlInsert = "INSERT INTO `cars`(`id`,`model`,`price`) VALUES (null,'chetana','4532')";
//     if ($conn->query($sqlInsert)) {
//         echo 'value inserted';
//     } else {
//         echo 'error';
//     }

// }

// echo $conn;
