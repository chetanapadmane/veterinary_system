<?php

include ('connect.php');

$conn = createConnection();
$sqlSelect = "SELECT * from `cars`";
$data = $conn->query($sqlSelect);

if ($data->num_rows > 0) {
    // output data of each row
    $i = 0;
    $jsonFormattedData = [];
    while ($row = $data->fetch_assoc()) {
        $jsonFormattedData[$i]['id'] = $row['id'];
        $jsonFormattedData[$i]['model'] = $row['model'];
        $jsonFormattedData[$i]['price'] = $row['price'];

        $i++;
    }
    echo json_encode($jsonFormattedData);
} else {
    echo "0 results";
}
$conn->close();